using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Client.Models;

//The model class for the client, used to make jsons by the client
public class UserItem
{
    public long Id { get; set; }
    public string? UserName { get; set; }
    public string? Name { get; set; }
    public string? Surname1 { get; set; }
    public string? Surname2 { get; set; }
    public string? BirthDate { get; set; }
    public long tel { get; set; }
    public string? menssage { get; set; }
}