﻿using System;

using System.Text.RegularExpressions;
using System.Collections.Generic;
using System.IO;
using System.Net;
using System.Net.Sockets;
using System.Threading;
using System.Text;
using System.Xml.Serialization;
//using simetrico;


namespace AsyncSrv
{
    // State object for reading client data asynchronously  
    public class StateObject
    {
        // Client  socket.  
        public Socket workSocket = null;
        // Size of receive buffer.   !!!!
        public const int BufferSize = 10; // 1024;
        // Receive buffer.  
        public byte[] buffer = new byte[BufferSize];
        // Received data string.  
        public StringBuilder sb = new StringBuilder();
    }

    public class AsynchronousSocketListener
    {
        private static int PORT = 11000;

        //the encryper (it makes things unreadalbe, like in the client)
        //private static AesEncrypter aesEncryption = new AesEncrypter();

        //The object that makes the petitions
        static HttpClient user = new HttpClient();

        // Thread signal.  
        public static ManualResetEvent allDone = new ManualResetEvent(false);

        public static int Main(String[] args)
        {
            StartListening();
            return 0;
        }

        public static void StartListening()
        {
            // Establish the local endpoint for the socket.  
            IPAddress ipAddress = GetLocalIpAddress();
            IPEndPoint localEndPoint = new IPEndPoint(ipAddress, PORT);

            // Create a TCP/IP socket.  
            Socket listener = new Socket(ipAddress.AddressFamily,
                SocketType.Stream, ProtocolType.Tcp);

            // Bind the socket to the local endpoint and listen for incoming connections.  
            try
            {
                user.BaseAddress = new Uri("http://localhost:5136/");
                user.DefaultRequestHeaders.Accept.Clear();


                listener.Bind(localEndPoint);
                listener.Listen(100);

                while (true)
                {
                    // Set the event to nonsignaled state.  
                    allDone.Reset();

                    // Start an asynchronous socket to listen for connections.  
                    Console.WriteLine("Waiting for a connection at {0}...", localEndPoint);
                    listener.BeginAccept(
                        new AsyncCallback(AcceptCallback),
                        listener);

                    // Wait until a connection is made before continuing.  
                    allDone.WaitOne();
                }

            }
            catch (Exception e)
            {
                Console.WriteLine(e.ToString());
            }

        }

        public static void AcceptCallback(IAsyncResult ar)
        {
            // Signal the main thread to continue.  
            allDone.Set();

            // Get the socket that handles the client request.  
            Socket listener = (Socket)ar.AsyncState;
            Socket handler = listener.EndAccept(ar);

            // Create the state object.  
            StateObject state = new StateObject();
            state.workSocket = handler;
            handler.BeginReceive(state.buffer, 0, StateObject.BufferSize, 0,
                new AsyncCallback(ReadCallback), state);
        }

        public static async void ReadCallback(IAsyncResult ar)
        {
            //bool iskey = false;
            Console.Write("_"); // Trace
            // Retrieve the state object and the handler socket  
            // from the asynchronous state object.  
            StateObject state = (StateObject)ar.AsyncState;
            Socket handler = state.workSocket;

            // Read data from the client socket.   
            int bytesRead = handler.EndReceive(ar);

            // Gets the amount of data that has been received from the network and 
            // is available to be read.
            if (handler.Available > 0)
            {
                Console.Write("0"); // Trace
                state.sb.Append(Encoding.ASCII.GetString(state.buffer, 0, bytesRead));
                // Not all data received. Get more.  
                handler.BeginReceive(state.buffer, 0, StateObject.BufferSize, 0, new AsyncCallback(ReadCallback), state);
            }
            else
            {
                if (bytesRead > 0)
                {
                    Console.Write("1"); // Trace
                    state.sb.Append(Encoding.ASCII.GetString(state.buffer, 0, bytesRead));
                }
                if (state.sb.Length > 1)
                {
                    Console.WriteLine("2"); // Trace
                    Console.WriteLine(state.workSocket.RemoteEndPoint);

                    byte[] byteArray = Encoding.ASCII.GetBytes(state.sb.ToString());
                    
                    string recibido = state.sb.ToString();

                    // All the data has been read from the client. Display it on the console.  
                    Console.WriteLine("Read {0} bytes from socket.\n{1}",
                        byteArray.Length, recibido);

                    if (recibido == "GETALL"){
                        recibido = "option 1 has been chosen";
                        Console.WriteLine(recibido);

                        //Get users from the API Rest
                        HttpResponseMessage response = await user.GetAsync("api/UserItems");
                        //Parse to string
                        recibido = await response.Content.ReadAsStringAsync();

                        Console.WriteLine(recibido);
                    }
                    else if (recibido.StartsWith("GET")){
                        Console.WriteLine("option 2 has been chosen");

                        int id = Int32.Parse(recibido.Substring(3));
                        //Get user by ID from the API Rest
                        HttpResponseMessage response = await user.GetAsync($"api/UserItems/{id}");
                        //Parse to string
                        recibido = await response.Content.ReadAsStringAsync();
                    }
                    else if (recibido.StartsWith("POS")){
                        Console.WriteLine("option 3 has been chosen");

                        string json = recibido.Substring(3);

                        // the json is codyfied so it can be sent
                        var content = new StringContent(json, Encoding.UTF8, "application/text");

                        //Post user in the API Rest
                        HttpResponseMessage response = await user.PostAsync("api/UserItems", content);

                        recibido = content.ToString();
                    }
                    else if (recibido.StartsWith("PUT")){
                        Console.WriteLine("option 4 has been chosen");

                        //Get the ID from the string
                        int id = Int32.Parse(Regex.Match(recibido, @"(\d+)$").Value);

                        //Remove the "PUT"
                        string jsonWithID = recibido.Substring(3);

                        //Remove the id
                        string json = Regex.Replace(jsonWithID, @"\d+$", "");

                        // the json is codyfied so it can be sent
                        var content = new StringContent(json, Encoding.UTF8, "application/text");

                        //Post user in the API Rest
                        HttpResponseMessage response = await user.PutAsync($"api/UserItems/{id}", content);

                        recibido = "The user has been updated succesfully";
                    }
                    else if (recibido.StartsWith("DEL")){
                        Console.WriteLine("option 5 has been chosen");

                        int id = Int32.Parse(Regex.Match(recibido, @"\d+").Value);
                        //Get user by ID from the API Rest
                        HttpResponseMessage response = await user.DeleteAsync($"api/UserItems/{id}");
                        //Parse to string
                        recibido = $"User with id {id} has been deleted";
                    }
                    //else if (recibido.StartsWith("KEY")){
                    //    iskey = true;
                    //    aesEncryption.getAes().Key = Convert.FromBase64String(recibido);
                    //    Console.WriteLine("IV set");
                    //}
                    //else if (recibido.StartsWith("IV")){
                    //    iskey = true;
                    //    aesEncryption.getAes().IV = Convert.FromBase64String(recibido);
                    //    Console.WriteLine("IV set");
                    //}
                   
                    // Echo the data back to the client.  
                    Send(handler, Encoding.ASCII.GetBytes(recibido));
                    
                    
                }
                else
                {
                    // If nothing has been received
                    Console.Write("3"); // Trace
                }
            }

        }

        private static void Send(Socket handler, byte[] data)
        {
            // NOT Transform the message to bytes (You dont have to do it anymore)
            byte[] byteData = data;
            // Begin sending the data to the remote device.  
            handler.BeginSend(byteData, 0, byteData.Length, 0, new AsyncCallback(SendCallback), handler);
        }

        private static void SendCallback(IAsyncResult ar)
        {
            try
            {
                // Retrieve the socket from the state object.  
                Socket handler = (Socket)ar.AsyncState;

                // Complete sending the data to the remote device.  
                int bytesSent = handler.EndSend(ar);
                Console.WriteLine("Sent {0} bytes to client.", bytesSent);

                handler.Shutdown(SocketShutdown.Both);
                handler.Close();
            }
            catch (Exception e)
            {
                Console.WriteLine(e.ToString());
            }
        }

        private static IPAddress GetLocalIpAddress()
        {
            List<IPAddress> ipAddressList = new List<IPAddress>();
            IPHostEntry ipHostInfo = Dns.GetHostEntry(Dns.GetHostName());
            IPAddress ipAddress = ipHostInfo.AddressList[0];
            int t = ipHostInfo.AddressList.Length;
            string ip;
            for (int i = 0; i < t; i++)
            {
                ip = ipHostInfo.AddressList[i].ToString();
                if (ip.Contains(".") && !ip.Equals("127.0.0.1"))
                {
                    ipAddressList.Add(ipHostInfo.AddressList[i]);
                }
            }
            if (ipAddressList.Count == 1)
            {
                return ipAddressList[0];
            }
            else
            {
                int i = 0;
                foreach (IPAddress ipa in ipAddressList)
                {
                    Console.WriteLine($"[{i++}]: {ipa}");
                }
                t = ipAddressList.Count - 1;
                System.Console.Write($"Opción [0-{t}]: ");
                string s = Console.ReadLine();
                if (Int32.TryParse(s, out int j))
                {
                    if ((j >= 0) && (j <= t))
                    {
                        return ipAddressList[j];
                    }
                }
                return null;
            }
        }

    }
}